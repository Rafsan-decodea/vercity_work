import java.util.*;
import java.util.ArrayList;
abstract class  Book{
    
protected   ArrayList Book_id  = new ArrayList();
            ArrayList  title  = new ArrayList();
            ArrayList  author = new ArrayList();
      public ArrayList price  = new ArrayList();

   void setid(int count)
   {

        Book_id.add(count);
   }
   void   getId()
   {
      for (int i=0 ; i<=Book_id.size(); i++)
      {
          System.out.print(Book_id.get(i));
         
      }  

   }

   void  Price(int prices)
   {
      price.add(prices);
       
   }

 void  show_price()
   {
       for (int i=0 ; i<=price.size(); i++)
       {
        System.out.println(price.get(i));
       }
   }


   
}