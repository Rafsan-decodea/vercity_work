
import java.util.*;

class main{

     public static void main(String[] args) {
         
     }
}