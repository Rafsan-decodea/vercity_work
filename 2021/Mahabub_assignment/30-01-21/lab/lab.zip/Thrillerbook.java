import java.util.*;

 class  Thrillerbook{

    static ArrayList Threelerbook  = new ArrayList();
     void  registerBook()
     {
        Scanner input = new Scanner(System.in);
        System.out.print("[+] input Thriller Book===>");
        String data = input.nextLine();
        Threelerbook.add(data);
         
     }

 }