import java.util.*;

 class EnglishThrillerBook{

   
     void  registerBook()
     {
        Scanner input = new Scanner(System.in);
        System.out.print("[+] input Thriller Book===>");
        String data = input.nextLine();
        Engbook.add(data);
         
     }
    //  Scanner input = new Scanner(System.in);
    //  System.out.print("[+]input Book Price");
    //  int data = input.nextInt();
    //  Book.price.add(data);

 }