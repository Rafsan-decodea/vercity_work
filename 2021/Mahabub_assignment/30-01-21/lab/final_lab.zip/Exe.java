
import java.util.*;

class Exe{

     public static void main(String[] args) {
         
        Thrillerbook th =  new Thrillerbook();

        th.book();
     }
}