import java.util.*;

 class  Thrillerbook{

    
     void book()
     {
        EnglishThrillerBook en = new EnglishThrillerBook();
        en.ragister();
         
     }

 }