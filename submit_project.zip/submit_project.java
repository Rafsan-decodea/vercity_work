import java.util.*;

class reverse{
    
     public void reversed_str(String data)
     {
       System.out.print("[+]Reverse string  is =>");
       for(int i=data.length()-1;i>=0;i--)
       {
         
         char data2 = data.charAt(i);
         System.out.print(data2);
       }
     }

  }
  
class binary_to_demical{
    
     public void bin_to_dem(String data)
     {
       int demical = Integer.parseInt(data,2);
       System.out.print("[+]Convert demical is => "+demical );
       
     }
}
  
class prime_number_add{
   
  public void prime_number_add(int n){
    
           
        int i, number, count,sum=0; 
    for(number = 1; number <= n; number++)
    {
      count = 0;
        for (i = 2; i <= number/2; i++)
        {
          if(number % i == 0)
          {
            count++;
        
            break;
          }
        }
        if(count == 0 && number != 1 )
        {
          sum = sum+number;
        }  
        
    }
    System.out.print("[+] the sum of prime number "+sum);
  }

}


class  swap{
  
    public void swap(String str)
    {

        char[] ch = str.toCharArray();

        char temp = ch[0]; 

        ch[0] = ch[ch.length - 1]; 

        ch[ch.length - 1] = temp;

       String data =String.valueOf(ch); 
        System.out.print("[+]The Swap "+str+" is "+data);
    }
}

class Employee{
  
    public void employee ()
    {
      System.out.print("\n-------++++String formatting+++----\n");
      System.out.print("Name\t\tYear of joining\t\t\n");
      System.out.print("Robert\t\t1994\t\t64C-Wall-Streat\n");
      System.out.print("Sam\t\t1990\t\t68D-Wall-streat");
    }
}


//change the decoder to your file name
 class Dcoder
 {
   public static void main(String args[])
   { 
     main_reverse reverse = new   main_reverse() ;
     reverse.main_reverse();
     main_bin_to_demical bin = new main_bin_to_demical();
     bin.main_bin_to_demical();
     main_prime_number_add prime = new main_prime_number_add();
     prime.main_prime_number_add();
     main_swap swap = new main_swap();
     swap.main_swap();
     main_employee emp = new main_employee();
     emp.main_employee();
    
 }
}

class main_reverse{
   
   public void main_reverse(){
     Scanner input = new Scanner(System.in);
     System.out.print("\n-------++++Reverse String+++----\n");
     System.out.print("[+]input the  String=>" );
     String data = input.nextLine();
     reverse rev = new reverse();
     rev.reversed_str(data);
    }
}

class main_bin_to_demical{
  
  public void main_bin_to_demical()
  {
    binary_to_demical bin = new binary_to_demical() ;
    Scanner input = new Scanner(System.in);
    System.out.print("\n-------++Binary to demical+++++----\n");
    System.out.print("\n[+]input binary num==>");
    String data = input.nextLine();
    bin.bin_to_dem(data);
  }
}

class main_prime_number_add{
   
   public void main_prime_number_add()
   {
     Scanner input = new Scanner(System.in);
     prime_number_add prime =new prime_number_add();
     System.out.print("\n------+++Sum of prime number++++-----\n");
     System.out.print("\n[+]input number ==>");
     int data = input.nextInt();
     prime.prime_number_add(data);
   }
}

class main_swap{
   
   public void main_swap()
   {
     swap swap = new swap();
     Scanner input = new Scanner(System.in);
     System.out.println("\n----+++Swap frist String+++----\n");
     System.out.print("[+]Enter your string =>");
     String str = input.nextLine();
     swap.swap(str);
   }
}

class main_employee{
  
  public void main_employee()
   {
     Employee emp = new Employee();
     emp.employee();
   }
}
    
